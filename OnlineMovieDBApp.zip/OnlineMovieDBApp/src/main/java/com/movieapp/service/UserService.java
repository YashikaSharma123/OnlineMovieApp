package com.movieapp.service;



import com.movieapp.exception.InvalidUserException;
import com.movieapp.model.User;


public interface UserService {
	
	String userLogin(String loginid,String password)throws InvalidUserException;
	void userSignup(User user);
//	String Order(User user);
	

}
