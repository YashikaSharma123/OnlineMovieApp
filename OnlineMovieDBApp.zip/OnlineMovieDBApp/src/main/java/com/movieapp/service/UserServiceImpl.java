package com.movieapp.service;

import com.movieapp.dao.UserDao;
import com.movieapp.dao.UserDaoImpl;

import com.movieapp.exception.InvalidUserException;
import com.movieapp.model.User;


public class UserServiceImpl implements UserService{

	UserDao userDAO=new UserDaoImpl();
	User user=null;
	public String userLogin(String loginid, String password) throws InvalidUserException {
		user=userDAO.userLogin(loginid, password);
		if(user==null)
			throw new InvalidUserException("Invalid Admin");
		return "Logined";		
	}

	public void userSignup(User user) {
		userDAO.userSignup(user);
		
	}

//	@Override
//	public String Order(User user) {
//		// TODO Auto-generated method stub
//		userDAO.Order(user);
//	}

	
	
	

}
