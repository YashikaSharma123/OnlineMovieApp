package com.movieapp.dao;

import java.util.List;
import com.movieapp.model.Movie;

public interface MovieDao {
	
	List<Movie> findMovieByCity(String city) ;
	List<Movie> findMovieByTheatre(String theatre) ;
	List<Movie> findMovieByPrice(int price) ;
	List<Movie> findMovieByDates(String dates);
	List<Movie> findMovieByCategory(String category) ;
	List<Movie> findMovieByRating(int rating) ;
	List<Movie> findMovieByActor(String actor) ;
	List<Movie> findMovieByActress(String actress);

	

}
