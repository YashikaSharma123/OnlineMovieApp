package com.movieapp.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.movieapp.model.User;

public class UserDaoImpl implements UserDao{

	public User userLogin(String loginid, String password){
		String sql = "select * from movieuser where loginid =? and password=?";
		Connection connection = DBConnection.openConnection();
		PreparedStatement statement = null;
		User user =null;
		
		try {
			statement = connection.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			statement.setString(1,loginid);
			statement.setString(2,password);
			ResultSet rs = statement.executeQuery();
			
			while(rs.next()) {
				String mobileno=rs.getString(3);
				String username=rs.getString(4);
				
					
				
				 user = new User(loginid,password,mobileno,username);
				//movieList.add(movie);
			}
			} catch(SQLException e) {
			System.out.println(e.getMessage());
		}finally {
			if(statement!=null)
				try {
					statement.close();
				}catch(SQLException e) {
					System.out.println(e.getMessage());
				}
			DBConnection.closeConnection();

		}
		return user;
		
		
	}

	public void userSignup(User user) {
		String sql = "Insert into movieuser values(?,?,?,?)";
		Connection connection = DBConnection.openConnection();
		PreparedStatement statement = null;
		
		
		try {
			statement = connection.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			statement.setString(1,user.getLoginId());
			statement.setString(2,user.getPassword());
			statement.setString(3,user.getMobileno());
			statement.setString(4,user.getUsername());
			statement.execute();
		
			
			} catch(SQLException e) {
			System.out.println(e.getMessage());
		}finally {
			if(statement!=null)
				try {
					statement.close();
				}catch(SQLException e) {
					System.out.println(e.getMessage());
				}
			DBConnection.closeConnection();

		}
		
	}

//	@Override
//	public void Order(User user) {
//		
//		
//	}
//	
	
}
