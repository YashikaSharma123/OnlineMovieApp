package com.movieapp.dao;


import com.movieapp.model.User;

public interface UserDao {
	
	User userLogin(String loginid,String password);
	void userSignup(User user);
//	void Order(User user);
	

}
