package com.movieapp.exception;

public class MovieNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;
	
		public MovieNotFoundException() {
			super();
			// TODO Auto-generated constructor stub
		}
	
		public MovieNotFoundException(String message) {
			super(message);
			// TODO Auto-generated constructor stub
		}

}
