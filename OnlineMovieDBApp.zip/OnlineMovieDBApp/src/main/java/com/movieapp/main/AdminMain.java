package com.movieapp.main;

import java.util.Scanner;

import com.movieapp.exception.IdNotFoundException;
import com.movieapp.model.Admin;
import com.movieapp.model.Movie;
import com.movieapp.service.AdminService;
import com.movieapp.service.AdminServiceImpl;

public class AdminMain {
	public static void main(String[] args) {
		
			AdminService service = new AdminServiceImpl();
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter your choice add|update|delete|getmovie");
			String value=sc.next();
			
			if(value.equals("add")) {
				Scanner sc1=new Scanner(System.in);
				
				System.out.println("Enter movieid");
				int movieid=sc1.nextInt();
				System.out.println("Enter name");
				String name=sc1.next();
				System.out.println("Enter city");
				String city=sc1.next();
				System.out.println("Enter theatre");
				String theatre=sc1.next();
				System.out.println("Enter language");
				String language=sc1.next();
				System.out.println("Enter category");
				String category=sc1.next();
				System.out.println("Enter director");
				String director=sc1.next();
				System.out.println("Enter actor");
				String actor=sc1.next();
				System.out.println("Enter actress");
				String actress=sc1.next();
				System.out.println("Enter date");
				String dates=sc1.next();
				System.out.println("Enter price");
				int price=sc1.nextInt();
				System.out.println("Enter rating");
				int rating=sc1.nextInt();
				//Movie movie=new Movie(2,"Ddlj","delhi","pvr","eng","scifi","yashika","bred","angel","12/3/2021",700,9);
				Movie movie=new Movie(movieid,name,city,theatre,language,category,director,actor,actress,dates,price,rating);
				service.addMovie(movie);
				
			}
		if(value.equals("update")) {
			try {
				Scanner sc2=new Scanner(System.in);
				
				System.out.println("Enter movieid");
				int movieid=sc2.nextInt();
				System.out.println("Enter price");
				int price=sc2.nextInt();
				service.updateMovie(movieid,price);
			} catch (IdNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(value.equals("delete")) {
			try {
				Scanner sc3=new Scanner(System.in);
				
				System.out.println("Enter movieid");
				int movieid=sc3.nextInt();
				service.deleteMovie(movieid);
			} catch (IdNotFoundException e) {
				e.printStackTrace();
			}
		}
		if(value.equals("getmovie")) {
			try {
				Scanner sc4=new Scanner(System.in);
				
				System.out.println("Enter movieid");
				int movieid=sc4.nextInt();
				
				System.out.println(service.getMovieById(movieid));
			} catch (IdNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
			
			

}
}