package com.movieapp.model;

public class Movie {
	
	private int movieid;
	private String name;
	private String city;
	private String theatre;
	private String language;
	private String category; 
	private String director; 
	private String actor; 
	private String actress; 
	private String dates;
	private Integer price;
	private Integer rating;
	
	
	public Movie(int movieid, String name, String city, String theatre, String language, String category,
			String director, String actor, String actress, String dates, Integer price, Integer rating) {
		super();
		this.movieid = movieid;
		this.name = name;
		this.city = city;
		this.theatre = theatre;
		this.language = language;
		this.category = category;
		this.director = director;
		this.actor = actor;
		this.actress = actress;
		this.dates = dates;
		this.price = price;
		this.rating = rating;
	}
	public Movie() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getMovieid() {
		return movieid;
	}
	public void setMovieid(int movieid) {
		this.movieid = movieid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getTheatre() {
		return theatre;
	}
	public void setTheatre(String theatre) {
		this.theatre = theatre;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getDirector() {
		return director;
	}
	public void setDirector(String director) {
		this.director = director;
	}
	public String getActor() {
		return actor;
	}
	public void setActor(String actor) {
		this.actor = actor;
	}
	public String getActress() {
		return actress;
	}
	public void setActress(String actress) {
		this.actress = actress;
	}
	public String getDates() {
		return dates;
	}
	public void setDates(String dates) {
		this.dates = dates;
	}
	public Integer getPrice() {
		return price;
	}
	public void setPrice(Integer price) {
		this.price = price;
	}
	public Integer getRating() {
		return rating;
	}
	public void setRating(Integer rating) {
		this.rating = rating;
	}
	@Override
	public String toString() {
		return "Movie [movieid=" + movieid + ", name=" + name + ", city=" + city + ", theatre=" + theatre
				+ ", language=" + language + ", category=" + category + ", director=" + director + ", actor=" + actor
				+ ", actress=" + actress + ", dates=" + dates + ", price=" + price + ", rating=" + rating + "]";
	}
	
		
	
}
